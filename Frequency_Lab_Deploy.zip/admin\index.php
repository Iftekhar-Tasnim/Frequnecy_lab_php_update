<?php
// Redirect to dashboard (which handles auth)
header('Location: dashboard.php');
exit;
